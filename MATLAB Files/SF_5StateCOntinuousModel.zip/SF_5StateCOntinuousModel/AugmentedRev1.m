clear;
clc;
%%  Parameters of virtuel patient
th1     =   0.85 ;    % in mg/dl/min 
th2     =   50 ;      % in mg/dl / U 
th3     =   60 ;      % in min 
th4     =   5 ;       % in /dl 
th5     =   20 ;      % in min 
ub      =   th1/th2 ; % ubasal in U/min
k       =   1;        % tuning gain
tau1    =   15;       % time delay to insulin injection
tau2    =   30;       % time delay for meal digestion
Gref    =   110;
%% Initial states 
x10     =   110 ;     % in mg/dl 
x20     =   ub ;      % ubasal 
x30     =   ub ;      % ubasal 
x40     =   0 ;       
x50     =   0 ;        
x0      =   [110; ub; ub; 0; 0];



%% System Definition

A   =   [0 -th2 0 th4 0; 0 -1/th3 1/th3 0 0; 0 0 -1/th3 0 0; 
        0 0 0 -1/th5 1/th5; 0 0 0 0 -1/th5];

B   =   [0 0; 0 0; 1/th3 0; 0 0; 0 1/th5];

Ba  =   [0 ; 0 ; 1/th3 ; 0 ; 0];   % B matrix just for input (insulin)
Bm  =   [0; 0; 1/th3; 0; 0];
Bc  =   [th1; 0; 0; 0; 0];         % Constant for glucose equation
%C   =   [1 0 0 0 0];
C   =   [1 0 0 0 0; 0 1 0 0 0; 0 0 1 0 0; 0 0 0 1 0; 0 0 0 0 1];
%D   =   [0 0 0];
D   =   [0 0 0; 0 0 0; 0 0 0; 0 0 0; 0 0 0];
Fin =   k*[1/th2 -th3 -th3 2 2];   % - Positivity gains
SF1 = [k/th2 -k*th3 (k*th5*th4)/(th2)];


%% Scenario 
Tfinal = 1500 ;    % duree de la simulation en minutes 
temps = 0 : 1 : Tfinal ;  

% Repas
repas = zeros (1, length(temps)) ;  % entree repas

 repas (110:120) = 3 ;    %3;        % 3   g/min pendant 10 minutes soit 30 g
  %  repas (480:489) = 3 ;           % 3   g/min pendant 10 minutes soit 30 g
   % repas (720:739) = 2.5;          % 2.5 g/min pendant 20 minutes soit 50 g
   % repas (1200:1229) = 3;          % 2   g/min pendant 30 minutes soit 60 g
    
   % repas (1440+480:1440+489) = 3 ;           % 3   g/min pendant 10 minutes soit 30 g
    %repas (1440+720:1440+739) = 2.5;          % 2.5 g/min pendant 20 minutes soit 50 g
   % repas (1440+1200:1440+1229) = 2;          % 2   g/min pendant 30 minutes soit 60 g



%%  Simulation
t = 0:0.01:2;
sim('ModelwithSF.slx',Tfinal);


%% State feedback - Pole placement
Cm = ctrb(A, B); % to check controllability
rank(Cm)
[V, E] = eig(A)
%p = [-0.0125; -0.0167; -0.0167; -0.05; -0.05]; %poles of the system
%p = [-1; -0.016; -0.015; -0.052; -0.051]; %positivity poles
p = [-0.0167; -0.0107; -0.0107; -0.05; -0.05];
F = -place(A, B, p) % Gains of the state feedback
%L = acker(A',C',p)'
L = [0.0048; 0; 0; 0; 0];
%s = A - L*C
%[b,a] = ss2tf(A, B, C, D) % Build transfer function
Fin1 = [0.000775  -2.2403   -2.7469    0.0746    0.2235]; % Results are
%obtained but input is not always positive

%[E] = eig(A+Ba*Fin)

%% Gains - LQR function implementation
% -0.001996
% 
% %%LQR function
 
% R = sdpvar(1,1);
% Q = sdpvar(5,5);
% L1 = R>=0;
% L2 = Q>=0;
% L3 = u>=0;
% L = L1+L2+L3;
% optimize(L);
% Q = double(Q);
% R = double(R);
% [K,S,P] = lqr(A,Ba,10*Q,R*1.1*10^-5)


%% PI parameters
Gr = 110 ;
kp = -100 ;
ki = - 0.3; 
k_aw = 2.5 ;
Td = 100;

